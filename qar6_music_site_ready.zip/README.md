# QAR6 Music Production — GitHub Pages site

This is a ready-to-deploy static site for QAR6 Music Production.

## How to use

1. Place your audio files in the `audio/` folder (create it in repo root).
2. Edit `songs.js` and add an object for each song:
```js
{
  title: "Song title",
  artist: "QAR6",
  file: "audio/your-file.mp3",
  type: "audio/mpeg"
}
```
3. Upload all files (including the `audio/` folder) to your GitHub repository.
4. In GitHub repo settings → Pages → Deploy from a branch → choose `main` and `/ (root)`.
5. After a minute, your site will be available at `https://username.github.io/repo-name/`.

## Replace placeholders
- Update the YouTube link in `index.html` (`https://youtube.com/yourchannel`) with your real channel URL.
- Replace `you@example.com` with your real contact email.
