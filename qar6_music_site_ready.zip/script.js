// script.js - renders the songs array into the page
document.getElementById('year').textContent = new Date().getFullYear();

function escapeHtml(text) {
  return String(text || '').replace(/[&<>"']/g, function(m) {
    return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]);
  });
}

function renderTracks() {
  const container = document.getElementById('tracksList');
  container.innerHTML = '';
  if (!Array.isArray(songs) || songs.length === 0) {
    container.innerHTML = '<p class="hint">Hələ mahnı əlavə edilməyib.</p>';
    return;
  }
  songs.forEach(s => {
    const div = document.createElement('div');
    div.className = 'track';
    div.innerHTML = `
      <div class="meta">
        <div>
          <h3>${escapeHtml(s.title)}</h3>
          <div class="artist">${escapeHtml(s.artist || 'QAR6')}</div>
        </div>
        <div class="actions">
          <a class="btn-download" href="${encodeURI(s.file)}" download>Yüklə</a>
        </div>
      </div>
      <audio controls preload="none">
        <source src="${encodeURI(s.file)}" type="${s.type || 'audio/mpeg'}">
        Your browser does not support audio.
      </audio>
    `;
    container.appendChild(div);
  });
}

renderTracks();
