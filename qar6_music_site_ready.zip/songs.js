// songs.js - add audio file entries here.
// Place audio files in the audio/ folder and reference them in 'file'.
// Example object:
// { title: "Song Title", artist: "QAR6", file: "audio/song-file.mp3", type: "audio/mpeg" }

const songs = [
  {
    title: "Menga azaring yetsin",
    artist: "QAR6",
    file: "audio/menga-azaring.mp3",
    type: "audio/mpeg"
  },
  {
    title: "Yeni Hisslər",
    artist: "QAR6",
    file: "audio/yeni-hissler.mp3",
    type: "audio/mpeg"
  }
];
